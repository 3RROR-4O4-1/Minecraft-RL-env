import time
from javascript import require, once


# Mineflayer + vec3 from JavaScript world
mineflayer = require("mineflayer")
vec3 = require("vec3")
Vec3 = require("vec3").Vec3

# ============================================
# CONFIG
# ============================================

server_host = "localhost"
server_port = 3000
reconnect = True
world = {}


# ============================================
# WORLD GENERATION
# ============================================

bot = mineflayer.createBot({
    'host': server_host,
    'port': server_port,
    'username': "world-eater",
    'hideErrors': False,
    'viewDistance': 40,
})
once(bot, 'login')
print("Bot has logged in and spawned.")
bot.chat("/tp -7.5 27 31.5")
time.sleep(120) # so that the chunks have time to load
print("Bot has waited for chunks to load.")


def categorize_block(block):
    # Unique base values spaced by 17 to avoid overlap with modifiers
    special_blocks = {
        "slab": 10, "stair": 27, "wall": 44, "portal": 61, "head": 78, "air": 1000, "void": 1000,
        "campfire": 129, "rod": 146, "chain": 163, "lantern": 180, "bars": 197, "pane": 214, "shrieker": 231,
        "fence": 248, "vines": 265, "ladder": 282, "trapdoor": 299, "door": 316, "sensor": 333,
        "slime": 350, "chest": 367, "enchanting": 384, "anvil": 401, "box": 418, "brewing": 435,
        "cauldron": 452, "composter": 469, "grindstone": 486, "lectern": 503, "bed": 520, "scaffolding": 537
    }

    block_name = block.name.lower()
    base_value = 1  # Default for unknown blocks
    if block.properties is None:
        block.properties = {}
    for i in ["sign", "plate", "torch", "button", "lever", "redstone", "tripwire", "comparator"]:
        if i in block_name:
            return 0

    # Check if the block is in the special category
    for block_type, base_val in special_blocks.items():
        if block_type in block_name:
            base_value = base_val
            break

    # Handling orientation
    orientations = {"north": 0, "south": 2, "east": 4, "west": 6}
    orientation_value = 0
    if "facing" in block.properties:
        facing = block.properties["facing"]
        if facing in orientations:
            orientation_value = orientations[facing]

    # Open/Closed status
    open_close_value = 0
    if "open" in block.properties:
        if block.properties["open"]:
            open_close_value = 1
        else:
            open_close_value = 2

    # Half block handling (slabs, stairs)
    half_block_value = 0
    if "half" in block.properties and block.properties["half"] == "top":
        half_block_value = 3

    # Special case: Trapdoors (hinge, half, open)
    trapdoor_value = 0
    if "trapdoor" in block_name:
        if "hinge" in block.properties:
            trapdoor_value = 4 if block.properties["hinge"] == "left" else 5

    # Compute final score
    final_value = base_value + orientation_value + open_close_value + half_block_value + trapdoor_value
    return final_value

class Block:
    def __init__(self, name, properties):
        self.name = name
        self.properties = properties

# ============================================
# Iterate through the loaded chunk columns
try:
    print("trying")
    for y in range(23, 51):  # Iterate through height levels
        for x in range(-15, 3):  # Iterate through width of the chunk
            for z in range(24, 250):  # Iterate through length of the chunk
                print("block")
                try :
                    block = bot.blockAt(Vec3(x, y, z))
                    arg = Block(block.name, block.properties)
                    print(arg.properties, arg.name)
                    val = categorize_block(arg)
                except:
                    val = 1000
                position_key = f"{x}/{y}/{z}"

                world[position_key] = val

except Exception as e:
    print(e)




# Clean up and exit
print("World data collected.")
print(len(world))
bot.quit()
print("Bot has disconnected.")

def save_world_to_file(world, filename):
    with open(filename, 'w') as file:
        for key, value in world.items():
            file.write(f"{key}: {value}\n")

save_world_to_file(world, 'data/epr.txt')

