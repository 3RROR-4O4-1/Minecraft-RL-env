# from AI_NEURO_EVOLUTION.train import train_neurev
# from AI_RL_DISCRETE.train import train_dqn
from AI_RL_CONTINUOUS.train import train_sac, train_ppo
# from AI_SB3.train import train_sb3

from dev.train import train_sac as train_sac_dev

if __name__ == "__main__":
    # train_neurev(pop_size=5, generations=50, mutation_rate=0.2, elite_nb=4)
    # train_dqn(num_episodes=100, max_steps=200)
    # train_sac(num_episodes=100, max_steps=50)
    # train_sac(num_episodes=300, max_steps=500, eval_mode=False)
    # train_sb3(NUM_ENVS=4, TOTAL_TIMESTEPS=500000)

    train_sac_dev(num_environments=4, num_episodes=50000, max_steps=10, sync_interval=15 ,eval_mode=False)