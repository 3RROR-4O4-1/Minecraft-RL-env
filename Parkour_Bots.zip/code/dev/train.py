import time
from dev.environment import MinecraftParkourEnv
from dev.SAC.agent import SACAgent

def train_sac(num_environments=1, num_episodes=100, max_steps=200, eval_mode=False, sync_interval=10):
    """
    Train multiple SAC agents in parallel environments. Every `sync_interval` episodes,
    the best-performing agent is selected, and all other agents copy its parameters.

    Args:
        num_environments (int): Number of parallel environments and agents.
        num_episodes (int): Total number of training episodes.
        max_steps (int): Maximum steps per episode.
        eval_mode (bool): Whether to run in evaluation mode.
        sync_interval (int): Interval (in episodes) at which to synchronize agents.
    """
    # Initialize multiple environments
    environments = []
    for i in range(num_environments):
        env = MinecraftParkourEnv(
            server_host="localhost",
            server_port=3000,
            username=f"Jerry_{i+1}",
            view_x_radius=2,
            view_z_radius=5,
            view_y_up=1,
            view_y_down=1,
            sleep_after_action=0.1
        )
        environments.append(env)
        # Wait for all environments to initialize properly otherwise I think there is a problem with matrix multiplication somewhere
        time.sleep(5.0)


    # Initialize agents, one per environment
    agents = []
    for i in range(num_environments):
        checkpoint_path = f"dev/SAC/storage/sac_agent_{i+1}.pth"
        try:
            agent = SACAgent.load_from_checkpoint(checkpoint_path)
        except FileNotFoundError:
            print(f"Checkpoint not found for Agent {i+1}. Initializing new agent.")
            # Initialize new agents if checkpoint doesn't exist
            sample_obs = environments[i].reset()
            obs_dim = sample_obs.shape[0]
            action_dim = 6  # [yaw, pitch, forward, left, right, jump]
            agent = SACAgent(
                obs_dim=obs_dim,
                action_dim=action_dim,
                lr=1e-3,
                gamma=0.99,
                tau=0.005,
                alpha=0.2,
                buffer_capacity=50000,
                batch_size=64
            )
        agents.append(agent)

    # Initialize tracking for agent performance
    agent_rewards_history = [[] for _ in range(num_environments)]  # List of lists

    # Training loop over episodes
    for episode in range(1, num_episodes + 1):
        # Reset all environments at the start of each episode
        observations = [env.reset() for env in environments]
        total_rewards = [0.0 for _ in environments]
        dones = [False for _ in environments]

        # Loop over each step within the episode
        for step in range(max_steps):
            actions = []

            # Select actions for all active environments
            for i, (agent, obs, done) in enumerate(zip(agents, observations, dones)):
                if not done:
                    raw_action = agent.select_action(obs, eval_mode=eval_mode)
                    # Scale the first two dimensions
                    delta_yaw = 0.3 * raw_action[0]
                    delta_pitch = 0.3 * raw_action[1]
                    # Construct the final action
                    action = [
                        delta_yaw,
                        delta_pitch,
                        raw_action[2],  # forward
                        raw_action[3],  # left
                        raw_action[4],  # right
                        raw_action[5],  # jump
                    ]
                else:
                    # No operation for done environments
                    action = [0, 0, 0, 0, 0, 0]
                actions.append(action)

            # Execute all actions in their respective environments
            next_observations = []
            rewards = []
            dones_step = []
            infos = []
            for i, (env, action) in enumerate(zip(environments, actions)):
                if not dones[i]:
                    next_ob, reward, done, info = env.step(action)
                else:
                    # Maintain previous observation and mark as done
                    next_ob, reward, done, info = observations[i], 0.0, True, {}
                next_observations.append(next_ob)
                rewards.append(reward)
                dones_step.append(done)
                infos.append(info)

            # Store transitions and accumulate rewards
            for i in range(num_environments):
                if not dones[i]:
                    agents[i].store_transition(
                        observations[i],
                        actions[i],
                        rewards[i],
                        next_observations[i],
                        dones_step[i]
                    )
                    total_rewards[i] += rewards[i]

            # Update all agents after processing the step
            for agent in agents:
                agent.update()

            # Update observations and done flags
            observations = next_observations
            dones = [dones[i] or dones_step[i] for i in range(num_environments)]

            # If all environments are done, end the episode early
            if all(dones):
                break

        # After episode ends, record rewards
        for i in range(num_environments):
            agent_rewards_history[i].append(total_rewards[i])

        # Every `sync_interval` episodes, synchronize agents
        if episode % sync_interval == 0:
            print(f"\n=== Synchronization at Episode {episode} ===")
            # Calculate average rewards over the last `sync_interval` episodes
            avg_rewards = []
            for i in range(num_environments):
                recent_rewards = agent_rewards_history[i][-sync_interval:]
                avg_reward = sum(recent_rewards) / len(recent_rewards) if recent_rewards else 0.0
                avg_rewards.append(avg_reward)
                print(f"Agent {i+1} Average Reward: {avg_reward:.2f}")

            # Identify the best agent
            best_agent_index = avg_rewards.index(max(avg_rewards))
            print(f"Best Agent: Agent {best_agent_index + 1} with Average Reward {avg_rewards[best_agent_index]:.2f}")

            # Get the state dict of the best agent
            best_agent_state = agents[best_agent_index].get_state_dict()

            # Copy the best agent's parameters to all other agents
            for i, agent in enumerate(agents):
                if i != best_agent_index:
                    agent.set_state_dict(best_agent_state)
                    print(f"Agent {i+1} has copied parameters from Agent {best_agent_index + 1}")

            print("Synchronization complete.\n")

        # Print the results for the episode
        for i in range(num_environments):
            print(f"Episode {episode}/{num_episodes} | Env {i+1} | Reward: {total_rewards[i]:.2f}")

    # Save all trained agents
    for i, agent in enumerate(agents):
        agent.save(f"dev/SAC/storage/sac_agent_{i+1}.pth")

    # Close all environments
    # this will generate an error but idk how to fix it
    for env in environments:
        env.close()
        time.sleep(5)

    print("Training complete!")
